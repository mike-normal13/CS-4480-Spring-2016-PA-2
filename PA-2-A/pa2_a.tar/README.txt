Mike Fleming
prog assignment 2 part A
CS 4480

I wrote a bunch of code that does not work. For some reason the only way I can get the B side to get called is when I use many messages. I will try to improve the assignment if time permits.
Compile with gcc and no flags like so:
	$ gcc prog2.c
Run like so:
	$ ./a.out
	